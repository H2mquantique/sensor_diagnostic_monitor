/*
 * File: DiagMonitor.c
 *
 * Code generated for Simulink model 'DiagMonitor'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Fri Nov  6 09:03:32 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "DiagMonitor.h"
#include "rtwtypes.h"
#include <math.h>
#include <string.h>

/* Named constants for Chart: '<S1>/Supervisor' */
#define DiagMonitor_IN_CONFIRMED       ((uint8_T)1U)
#define DiagMonitor_IN_HEALING         ((uint8_T)2U)
#define DiagMonitor_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define DiagMonitor_IN_NO_FAULT        ((uint8_T)3U)
#define DiagMonitor_IN_PENDING         ((uint8_T)4U)

/* Forward declaration for local functions */
static void DiagMoni_enter_atomic_CONFIRMED(const uint8_T *testbits, uint8_T
  *DiagMonitor_Y_state, uint8_T *DiagMonitor_Y_dtc, boolean_T *DiagMonitor_Y_mil,
  boolean_T *DiagMonitor_Y_ff_valid);

/* Function for Chart: '<S1>/Supervisor' */
static void DiagMoni_enter_atomic_CONFIRMED(const uint8_T *testbits, uint8_T
  *DiagMonitor_Y_state, uint8_T *DiagMonitor_Y_dtc, boolean_T *DiagMonitor_Y_mil,
  boolean_T *DiagMonitor_Y_ff_valid)
{
  /* Outport: '<Root>/state' */
  *DiagMonitor_Y_state = 2U;

  /* Outport: '<Root>/mil' */
  *DiagMonitor_Y_mil = true;

  /* Outport: '<Root>/ff_valid' incorporates:
   *  Outport: '<Root>/dtc'
   */
  if (!*DiagMonitor_Y_ff_valid) {
    *DiagMonitor_Y_dtc = *testbits;
    *DiagMonitor_Y_ff_valid = true;
  }

  /* End of Outport: '<Root>/ff_valid' */
}

/* Model step function */
void DiagMonitor_step(RT_MODEL_DiagMonitor_T *const DiagMonitor_M, real_T
                      DiagMonitor_U_v1, real_T DiagMonitor_U_v2, real_T
                      DiagMonitor_U_ect, uint8_T *DiagMonitor_Y_state, uint8_T
                      *DiagMonitor_Y_dtc, boolean_T *DiagMonitor_Y_mil,
                      boolean_T *DiagMonitor_Y_ff_valid)
{
  DW_DiagMonitor_T *DiagMonitor_DW = DiagMonitor_M->dwork;
  uint8_T testbits;
  boolean_T any_bad;
  boolean_T corr_bad;
  boolean_T range_bad;
  boolean_T rate_bad;

  /* Outputs for Atomic SubSystem: '<Root>/DiagMonitor' */
  /* MATLAB Function: '<S1>/Rationality' incorporates:
   *  Inport: '<Root>/ect'
   *  Inport: '<Root>/v1'
   *  Inport: '<Root>/v2'
   *  UnitDelay: '<S1>/v1_z'
   */
  range_bad = ((DiagMonitor_U_v1 < 0.2) || (DiagMonitor_U_v1 > 4.8));
  rate_bad = (DiagMonitor_DW->prev_valid && (fabs(DiagMonitor_U_v1 -
    DiagMonitor_DW->v1_z_DSTATE) > 1.5));
  DiagMonitor_DW->prev_valid = true;
  corr_bad = (fabs((DiagMonitor_U_v1 - 0.5) / 4.0 * 100.0 - (DiagMonitor_U_v2 -
    0.25) / 2.0 * 100.0) > 10.0);
  any_bad = (range_bad || rate_bad || corr_bad);
  testbits = (uint8_T)(((rate_bad << 1) + range_bad) + (corr_bad << 2));
  range_bad = (DiagMonitor_U_ect >= 60.0);
  if (range_bad) {
    if (any_bad) {
      DiagMonitor_DW->fc = fmin(DiagMonitor_DW->fc + 1.0, 20.0);
    } else {
      DiagMonitor_DW->fc = fmax(DiagMonitor_DW->fc - 1.0, 0.0);
    }
  }

  /* Chart: '<S1>/Supervisor' incorporates:
   *  MATLAB Function: '<S1>/Rationality'
   */
  if (DiagMonitor_DW->is_active_c3_DiagMonitor == 0U) {
    DiagMonitor_DW->is_active_c3_DiagMonitor = 1U;
    DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_NO_FAULT;

    /* Outport: '<Root>/state' */
    *DiagMonitor_Y_state = 0U;

    /* Outport: '<Root>/mil' */
    *DiagMonitor_Y_mil = false;

    /* Outport: '<Root>/dtc' */
    *DiagMonitor_Y_dtc = 0U;

    /* Outport: '<Root>/ff_valid' */
    *DiagMonitor_Y_ff_valid = false;
    DiagMonitor_DW->healCnt = 0.0;
  } else {
    switch (DiagMonitor_DW->is_c3_DiagMonitor) {
     case DiagMonitor_IN_CONFIRMED:
      /* Outport: '<Root>/state' */
      *DiagMonitor_Y_state = 2U;

      /* Outport: '<Root>/mil' */
      *DiagMonitor_Y_mil = true;
      if (range_bad && (!any_bad)) {
        DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_HEALING;

        /* Outport: '<Root>/state' */
        *DiagMonitor_Y_state = 3U;
        DiagMonitor_DW->healCnt = 0.0;
      } else {
        /* Outport: '<Root>/dtc' */
        *DiagMonitor_Y_dtc |= testbits;
      }
      break;

     case DiagMonitor_IN_HEALING:
      /* Outport: '<Root>/state' */
      *DiagMonitor_Y_state = 3U;

      /* Outport: '<Root>/mil' */
      *DiagMonitor_Y_mil = true;
      if (any_bad) {
        DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_CONFIRMED;
        DiagMoni_enter_atomic_CONFIRMED(&testbits, DiagMonitor_Y_state,
          DiagMonitor_Y_dtc, DiagMonitor_Y_mil, DiagMonitor_Y_ff_valid);
      } else if (DiagMonitor_DW->healCnt >= 300.0) {
        DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_NO_FAULT;

        /* Outport: '<Root>/state' */
        *DiagMonitor_Y_state = 0U;

        /* Outport: '<Root>/mil' */
        *DiagMonitor_Y_mil = false;

        /* Outport: '<Root>/dtc' */
        *DiagMonitor_Y_dtc = 0U;

        /* Outport: '<Root>/ff_valid' */
        *DiagMonitor_Y_ff_valid = false;
        DiagMonitor_DW->healCnt = 0.0;
      } else {
        DiagMonitor_DW->healCnt++;
      }
      break;

     case DiagMonitor_IN_NO_FAULT:
      /* Outport: '<Root>/state' */
      *DiagMonitor_Y_state = 0U;

      /* Outport: '<Root>/mil' */
      *DiagMonitor_Y_mil = false;
      if (DiagMonitor_DW->fc > 0.0) {
        DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_PENDING;

        /* Outport: '<Root>/state' */
        *DiagMonitor_Y_state = 1U;
      }
      break;

     default:
      /* Outport: '<Root>/state' */
      /* case IN_PENDING: */
      *DiagMonitor_Y_state = 1U;

      /* Outport: '<Root>/mil' */
      *DiagMonitor_Y_mil = false;
      if (DiagMonitor_DW->fc >= 20.0) {
        DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_CONFIRMED;
        DiagMoni_enter_atomic_CONFIRMED(&testbits, DiagMonitor_Y_state,
          DiagMonitor_Y_dtc, DiagMonitor_Y_mil, DiagMonitor_Y_ff_valid);
      } else if (DiagMonitor_DW->fc == 0.0) {
        DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_NO_FAULT;

        /* Outport: '<Root>/state' */
        *DiagMonitor_Y_state = 0U;

        /* Outport: '<Root>/dtc' */
        *DiagMonitor_Y_dtc = 0U;

        /* Outport: '<Root>/ff_valid' */
        *DiagMonitor_Y_ff_valid = false;
        DiagMonitor_DW->healCnt = 0.0;
      }
      break;
    }
  }

  /* End of Chart: '<S1>/Supervisor' */

  /* Update for UnitDelay: '<S1>/v1_z' incorporates:
   *  Inport: '<Root>/v1'
   */
  DiagMonitor_DW->v1_z_DSTATE = DiagMonitor_U_v1;

  /* End of Outputs for SubSystem: '<Root>/DiagMonitor' */
}

/* Model initialize function */
void DiagMonitor_initialize(RT_MODEL_DiagMonitor_T *const DiagMonitor_M, real_T *
  DiagMonitor_U_v1, real_T *DiagMonitor_U_v2, real_T *DiagMonitor_U_rpm, real_T *
  DiagMonitor_U_load, real_T *DiagMonitor_U_ect, uint8_T *DiagMonitor_Y_state,
  uint8_T *DiagMonitor_Y_dtc, boolean_T *DiagMonitor_Y_mil, boolean_T
  *DiagMonitor_Y_ff_valid)
{
  DW_DiagMonitor_T *DiagMonitor_DW = DiagMonitor_M->dwork;

  /* Registration code */

  /* states (dwork) */
  (void) memset((void *)DiagMonitor_DW, 0,
                sizeof(DW_DiagMonitor_T));

  /* external inputs */
  *DiagMonitor_U_v1 = 0.0;
  *DiagMonitor_U_v2 = 0.0;
  *DiagMonitor_U_rpm = 0.0;
  *DiagMonitor_U_load = 0.0;
  *DiagMonitor_U_ect = 0.0;

  /* external outputs */
  *DiagMonitor_Y_state = 0U;
  *DiagMonitor_Y_dtc = 0U;
  *DiagMonitor_Y_mil = false;
  *DiagMonitor_Y_ff_valid = false;

  /* SystemInitialize for Atomic SubSystem: '<Root>/DiagMonitor' */
  /* SystemInitialize for MATLAB Function: '<S1>/Rationality' */
  DiagMonitor_DW->fc = 0.0;
  DiagMonitor_DW->prev_valid = false;

  /* SystemInitialize for Chart: '<S1>/Supervisor' */
  DiagMonitor_DW->is_active_c3_DiagMonitor = 0U;
  DiagMonitor_DW->is_c3_DiagMonitor = DiagMonitor_IN_NO_ACTIVE_CHILD;
  DiagMonitor_DW->healCnt = 0.0;

  /* InitializeConditions for Outport: '<Root>/state' incorporates:
   *  Chart: '<S1>/Supervisor'
   */
  *DiagMonitor_Y_state = 0U;

  /* InitializeConditions for Outport: '<Root>/dtc' incorporates:
   *  Chart: '<S1>/Supervisor'
   */
  *DiagMonitor_Y_dtc = 0U;

  /* InitializeConditions for Outport: '<Root>/mil' incorporates:
   *  Chart: '<S1>/Supervisor'
   */
  *DiagMonitor_Y_mil = false;

  /* InitializeConditions for Outport: '<Root>/ff_valid' incorporates:
   *  Chart: '<S1>/Supervisor'
   */
  *DiagMonitor_Y_ff_valid = false;

  /* End of SystemInitialize for SubSystem: '<Root>/DiagMonitor' */
}

/* Model terminate function */
void DiagMonitor_terminate(RT_MODEL_DiagMonitor_T *const DiagMonitor_M)
{
  /* (no terminate code required) */
  UNUSED_PARAMETER(DiagMonitor_M);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
