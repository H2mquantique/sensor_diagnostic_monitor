/*
 * File: ert_main.c
 *
 * Code generated for Simulink model 'DiagMonitor'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Fri Nov  6 09:03:32 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include <stddef.h>
#include <stdio.h>            /* This example main program uses printf/fflush */
#include "DiagMonitor.h"               /* Model header file */

static RT_MODEL_DiagMonitor_T DiagMonitor_M_;
static RT_MODEL_DiagMonitor_T *const DiagMonitor_MPtr = &DiagMonitor_M_;/* Real-time model */
static DW_DiagMonitor_T DiagMonitor_DW;/* Observable states */

/* '<Root>/v1' */
static real_T DiagMonitor_U_v1;

/* '<Root>/v2' */
static real_T DiagMonitor_U_v2;

/* '<Root>/rpm' */
static real_T DiagMonitor_U_rpm;

/* '<Root>/load' */
static real_T DiagMonitor_U_load;

/* '<Root>/ect' */
static real_T DiagMonitor_U_ect;

/* '<Root>/state' */
static uint8_T DiagMonitor_Y_state;

/* '<Root>/dtc' */
static uint8_T DiagMonitor_Y_dtc;

/* '<Root>/mil' */
static boolean_T DiagMonitor_Y_mil;

/* '<Root>/ff_valid' */
static boolean_T DiagMonitor_Y_ff_valid;

/*
 * Associating rt_OneStep with a real-time clock or interrupt service routine
 * is what makes the generated code "real-time".  The function rt_OneStep is
 * always associated with the base rate of the model.  Subrates are managed
 * by the base rate from inside the generated code.  Enabling/disabling
 * interrupts and floating point context switches are target specific.  This
 * example code indicates where these should take place relative to executing
 * the generated code step function.  Overrun behavior should be tailored to
 * your application needs.  This example simply sets an error status in the
 * real-time model and returns from rt_OneStep.
 */
void rt_OneStep(RT_MODEL_DiagMonitor_T *const DiagMonitor_M);
void rt_OneStep(RT_MODEL_DiagMonitor_T *const DiagMonitor_M)
{
  static boolean_T OverrunFlag = false;

  /* Disable interrupts here */

  /* Check for overrun */
  if (OverrunFlag) {
    rtmSetErrorStatus(DiagMonitor_M, "Overrun");
    return;
  }

  OverrunFlag = true;

  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  /* Set model inputs here */

  /* Step the model */
  DiagMonitor_step(DiagMonitor_M, DiagMonitor_U_v1, DiagMonitor_U_v2,
                   DiagMonitor_U_ect, &DiagMonitor_Y_state, &DiagMonitor_Y_dtc,
                   &DiagMonitor_Y_mil, &DiagMonitor_Y_ff_valid);

  /* Get model outputs here */

  /* Indicate task complete */
  OverrunFlag = false;

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

/*
 * The example main function illustrates what is required by your
 * application code to initialize, execute, and terminate the generated code.
 * Attaching rt_OneStep to a real-time clock is target specific. This example
 * illustrates how you do this relative to initializing the model.
 */
int_T main(int_T argc, const char *argv[])
{
  RT_MODEL_DiagMonitor_T *const DiagMonitor_M = DiagMonitor_MPtr;

  /* Unused arguments */
  (void)(argc);
  (void)(argv);

  /* Pack model data into RTM */
  DiagMonitor_M->dwork = &DiagMonitor_DW;

  /* Initialize model */
  DiagMonitor_initialize(DiagMonitor_M, &DiagMonitor_U_v1, &DiagMonitor_U_v2,
    &DiagMonitor_U_rpm, &DiagMonitor_U_load, &DiagMonitor_U_ect,
    &DiagMonitor_Y_state, &DiagMonitor_Y_dtc, &DiagMonitor_Y_mil,
    &DiagMonitor_Y_ff_valid);

  /* Attach rt_OneStep to a timer or interrupt service routine with
   * period 0.01 seconds (base rate of the model) here.
   * The call syntax for rt_OneStep is
   *
   *  rt_OneStep(DiagMonitor_M);
   */
  printf("Warning: The simulation will run forever. "
         "Generated ERT main won't simulate model step behavior. "
         "To change this behavior select the 'MAT-file logging' option.\n");
  fflush((NULL));
  while (rtmGetErrorStatus(DiagMonitor_M) == (NULL)) {
    /*  Perform application tasks here */
  }

  /* Terminate model */
  DiagMonitor_terminate(DiagMonitor_M);
  return 0;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
