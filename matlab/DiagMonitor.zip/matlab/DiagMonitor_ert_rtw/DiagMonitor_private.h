/*
 * File: DiagMonitor_private.h
 *
 * Code generated for Simulink model 'DiagMonitor'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Fri Nov  6 09:03:32 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DiagMonitor_private_h_
#define RTW_HEADER_DiagMonitor_private_h_
#include "rtwtypes.h"
#include "DiagMonitor_types.h"
#endif                                 /* RTW_HEADER_DiagMonitor_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
