/*
 * File: DiagMonitor.h
 *
 * Code generated for Simulink model 'DiagMonitor'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Fri Nov  6 09:03:32 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DiagMonitor_h_
#define RTW_HEADER_DiagMonitor_h_
#ifndef DiagMonitor_COMMON_INCLUDES_
#define DiagMonitor_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* DiagMonitor_COMMON_INCLUDES_ */

#include "DiagMonitor_types.h"
#include <string.h>
#include "rt_defines.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T v1_z_DSTATE;                  /* '<S1>/v1_z' */
  real_T healCnt;                      /* '<S1>/Supervisor' */
  real_T fc;                           /* '<S1>/Rationality' */
  uint8_T is_c3_DiagMonitor;           /* '<S1>/Supervisor' */
  uint8_T is_active_c3_DiagMonitor;    /* '<S1>/Supervisor' */
  boolean_T prev_valid;                /* '<S1>/Rationality' */
} DW_DiagMonitor_T;

/* Real-time Model Data Structure */
struct tag_RTM_DiagMonitor_T {
  const char_T * volatile errorStatus;
  DW_DiagMonitor_T *dwork;
};

/* Model entry point functions */
extern void DiagMonitor_initialize(RT_MODEL_DiagMonitor_T *const DiagMonitor_M,
  real_T *DiagMonitor_U_v1, real_T *DiagMonitor_U_v2, real_T *DiagMonitor_U_rpm,
  real_T *DiagMonitor_U_load, real_T *DiagMonitor_U_ect, uint8_T
  *DiagMonitor_Y_state, uint8_T *DiagMonitor_Y_dtc, boolean_T *DiagMonitor_Y_mil,
  boolean_T *DiagMonitor_Y_ff_valid);
extern void DiagMonitor_step(RT_MODEL_DiagMonitor_T *const DiagMonitor_M, real_T
  DiagMonitor_U_v1, real_T DiagMonitor_U_v2, real_T DiagMonitor_U_ect, uint8_T
  *DiagMonitor_Y_state, uint8_T *DiagMonitor_Y_dtc, boolean_T *DiagMonitor_Y_mil,
  boolean_T *DiagMonitor_Y_ff_valid);
extern void DiagMonitor_terminate(RT_MODEL_DiagMonitor_T *const DiagMonitor_M);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('diag_monitor/DiagMonitor')    - opens subsystem diag_monitor/DiagMonitor
 * hilite_system('diag_monitor/DiagMonitor/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'diag_monitor'
 * '<S1>'   : 'diag_monitor/DiagMonitor'
 * '<S2>'   : 'diag_monitor/DiagMonitor/Rationality'
 * '<S3>'   : 'diag_monitor/DiagMonitor/Supervisor'
 */
#endif                                 /* RTW_HEADER_DiagMonitor_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
